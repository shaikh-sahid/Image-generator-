import { v } from "convex/values";
import { mutation, query, action, internalQuery, internalMutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import { api, internal } from "./_generated/api";

export const generateImage = mutation({
  args: {
    prompt: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be logged in to generate images");
    }

    const generationId = await ctx.db.insert("imageGenerations", {
      userId,
      prompt: args.prompt,
      status: "pending",
    });

    // Schedule the actual image generation
    await ctx.scheduler.runAfter(0, internal.images.processImageGeneration, {
      generationId,
    });

    return generationId;
  },
});

export const processImageGeneration = action({
  args: {
    generationId: v.id("imageGenerations"),
  },
  handler: async (ctx, args) => {
    const generation = await ctx.runQuery(internal.images.getGeneration, {
      generationId: args.generationId,
    });

    if (!generation) {
      throw new Error("Generation not found");
    }

    try {
      // Use the bundled OpenAI API
      const response = await fetch("https://api.openai.com/v1/images/generations", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${process.env.CONVEX_OPENAI_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "dall-e-3",
          prompt: generation.prompt,
          n: 1,
          size: "1024x1024",
          quality: "standard",
        }),
      });

      if (!response.ok) {
        const error = await response.text();
        throw new Error(`OpenAI API error: ${error}`);
      }

      const data = await response.json();
      const imageUrl = data.data[0].url;

      // Download the image and store it in Convex storage
      const imageResponse = await fetch(imageUrl);
      const imageBlob = await imageResponse.blob();
      
      const storageId = await ctx.storage.store(imageBlob);

      // Update the generation record
      await ctx.runMutation(internal.images.updateGeneration, {
        generationId: args.generationId,
        storageId,
        status: "completed",
      });
    } catch (error) {
      // Update with error status
      await ctx.runMutation(internal.images.updateGeneration, {
        generationId: args.generationId,
        status: "failed",
        error: error instanceof Error ? error.message : "Unknown error",
      });
    }
  },
});

export const getGeneration = internalQuery({
  args: {
    generationId: v.id("imageGenerations"),
  },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.generationId);
  },
});

export const updateGeneration = internalMutation({
  args: {
    generationId: v.id("imageGenerations"),
    storageId: v.optional(v.id("_storage")),
    status: v.union(v.literal("pending"), v.literal("completed"), v.literal("failed")),
    error: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const updates: any = {
      status: args.status,
    };
    
    if (args.storageId) {
      updates.storageId = args.storageId;
    }
    
    if (args.error) {
      updates.error = args.error;
    }

    await ctx.db.patch(args.generationId, updates);
  },
});

export const getUserGenerations = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const generations = await ctx.db
      .query("imageGenerations")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .take(20);

    // Get storage URLs for completed generations
    return await Promise.all(
      generations.map(async (generation) => ({
        ...generation,
        imageUrl: generation.storageId 
          ? await ctx.storage.getUrl(generation.storageId)
          : null,
      }))
    );
  },
});
